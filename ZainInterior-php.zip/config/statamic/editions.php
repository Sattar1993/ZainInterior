<?php

return [

    'pro' => false,

    'addons' => [
        //
    ],

];
