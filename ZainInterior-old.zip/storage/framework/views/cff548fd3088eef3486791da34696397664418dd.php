<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Laravel React application</title>
        <link href="<?php echo e(mix('css/app.css')); ?>" rel="stylesheet" type="text/css">
    </head>
    <body>
        <div id="header"></div>
		<div id="contant"></div>
        <div id="About"></div>
		<div id="Footer"></div>


        <script src="<?php echo e(mix('js/app.js')); ?>" ></script>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\ZainInterior\resources\views/app.blade.php ENDPATH**/ ?>