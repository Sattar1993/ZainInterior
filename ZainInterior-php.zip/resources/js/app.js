
require('./bootstrap');



/* Import the Main component */


require('./components/App');
require('./components/Contant');
require('./components/About');
require('./components/Blog');
require('./components/Containt2ndpage');
require('./components/Footer');
require('./components/BlogDetail');
require('./components/AboutUs');
require('./components/ContactUs');